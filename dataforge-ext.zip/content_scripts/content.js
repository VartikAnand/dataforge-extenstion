if (window.location.href.includes('linkedin.com/in/')) {
    console.log('LinkedIn Profile Detected');
    // You can perform actions on the LinkedIn page here, like scraping data or modifying the UI
  }
  